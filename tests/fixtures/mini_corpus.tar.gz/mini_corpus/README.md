# synthcal — synthetic test fixture

This directory is a **fixture**, not a real project. It exists to give the
africalim retrieval primitives (`core/retrieval.py`) and the janskie agent
something to search, read, and version-check during tests.

`synthcal` pretends to be a tiny radio-interferometry calibration toolkit:
it has a Typer CLI stub, an imaging module, a calibration module, an I/O
module, and a single test. Function bodies are deliberately stubbed
(`raise NotImplementedError`) — nothing here actually runs an algorithm.

## Why this directory has its own `.git/`

The retrieval primitives need to read commit hashes via `gitpython`, so the
fixture is a real git repository with at least two commits. The nested
`.git/` directory lives **inside** this folder. The parent africalim repo
sees the fixture's working tree as untracked files (which is what we want);
it does **not** treat the fixture as a git submodule because nothing in
the parent's index has a gitlink for it.

If you ever see `tests/fixtures/mini_corpus` reported as a submodule by
the parent repo's `git status`, something has gone wrong — investigate
before committing.
