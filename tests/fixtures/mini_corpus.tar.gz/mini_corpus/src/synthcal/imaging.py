"""Imaging primitives: PSF, dirty image, and a single CLEAN minor cycle."""

from __future__ import annotations

from typing import Any


def psf_from_uv(uvw: Any, weights: Any, npix: int = 1024, cell_arcsec: float = 1.0) -> Any:
    """Compute the point-spread function from uv-coverage and weights.

    Parameters
    ----------
    uvw : array-like
        Baselines in metres, shape ``(nrow, 3)``.
    weights : array-like
        Per-visibility imaging weights, shape ``(nrow, nchan)``.
    npix : int
        Image side length in pixels.
    cell_arcsec : float
        Pixel scale in arcseconds.
    """
    raise NotImplementedError("psf_from_uv is a fixture stub")


def dirty_image(vis: Any, npix: int = 1024, cell_arcsec: float = 1.0) -> Any:
    """Produce a dirty image by gridding visibilities and inverse FFT-ing."""
    raise NotImplementedError("dirty_image is a fixture stub")


def clean_step(image: Any, gain: float = 0.1, threshold_jy: float = 1e-3) -> Any:
    """Run one Hogbom-style CLEAN minor cycle over the residual image."""
    raise NotImplementedError("clean_step is a fixture stub")
