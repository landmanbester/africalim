"""Measurement-set readers and FITS writers."""

from __future__ import annotations

from pathlib import Path
from typing import Any


def read_ms(path: Path, columns: tuple[str, ...] = ("DATA", "WEIGHT", "FLAG")) -> Any:
    """Read selected columns from an MS into an in-memory dataset."""
    raise NotImplementedError("read_ms is a fixture stub")


def write_fits(image: Any, path: Path, overwrite: bool = True) -> None:
    """Write a 2-D image array to a FITS file with WCS headers."""
    raise NotImplementedError("write_fits is a fixture stub")
