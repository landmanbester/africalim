"""Command-line entry point for the synthcal fixture toolkit."""

from __future__ import annotations

from pathlib import Path

import typer

app = typer.Typer(help="synthcal: a synthetic calibration toolkit (fixture).")


@app.command()
def image(
    ms: Path = typer.Argument(..., help="Path to the input measurement set."),
    output: Path = typer.Option(Path("dirty.fits"), help="Output FITS image."),
    niter: int = typer.Option(0, help="Number of CLEAN minor-cycle iterations."),
) -> None:
    """Produce a dirty image (and, if niter > 0, a CLEAN model) from an MS."""
    from synthcal.imaging import clean_step, dirty_image
    from synthcal.io import read_ms, write_fits

    vis = read_ms(ms)
    img = dirty_image(vis)
    for _ in range(niter):
        img = clean_step(img)
    write_fits(img, output)


@app.command()
def flag(
    ms: Path = typer.Argument(..., help="Measurement set to flag in place."),
    threshold: float = typer.Option(5.0, help="Sigma threshold for outlier flagging."),
) -> None:
    """Flag visibilities above a sigma threshold (stub)."""
    raise NotImplementedError("flag is a fixture stub")
