"""synthcal — synthetic radio-interferometry calibration toolkit (fixture)."""

__version__ = "0.0.1"
