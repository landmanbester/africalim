"""Direction-independent gain calibration primitives."""

from __future__ import annotations

from typing import Any


def solve_gains(vis: Any, model: Any, max_iter: int = 50, tol: float = 1e-6) -> Any:
    """Solve for per-antenna complex gains against a sky model.

    Uses a StefCal-style alternating least-squares update. Returns a gains
    array of shape ``(nant, ntime, nchan)``.
    """
    raise NotImplementedError("solve_gains is a fixture stub")


def apply_gains(vis: Any, gains: Any, inverse: bool = False) -> Any:
    """Apply (or, if ``inverse`` is True, undo) per-antenna gains to vis."""
    raise NotImplementedError("apply_gains is a fixture stub")
