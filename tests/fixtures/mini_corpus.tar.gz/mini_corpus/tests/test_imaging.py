"""Trivial smoke tests for synthcal.imaging."""

from __future__ import annotations

import pytest

from synthcal import imaging


def test_psf_is_a_callable() -> None:
    assert callable(imaging.psf_from_uv)


def test_dirty_image_raises_until_implemented() -> None:
    with pytest.raises(NotImplementedError):
        imaging.dirty_image(vis=None)
